<?php 
require('function.php');

// if (isset($_POST["submit"])) {
//   $id_pelanggan = $_POST["id_pelanggan"];
//   if (tambah_transaksi($_POST) > 0) {
//       echo '<script>alert("Berhasil");window.location="berhasil.php?idm='.$id_pelanggan.'"</script>';
//   } else {
//       echo "
//   <script>
//     alert('Data gagal ditambahkan!');
//     document.location.href = 'daftar-transaksi.php';
//   </script>";
//   }
// }
?>

<?php
include("connection.php");
$data = mysqli_query($connection, "SELECT max((id_transaksi) + 1) as id_trans FROM transaksi");
$data1 = mysqli_query($connection, "SELECT max(id_pelanggan) as id_pe FROM pelanggan");
$row = mysqli_fetch_array($data);
$row1 = mysqli_fetch_array($data1);
?>

<!DOCTYPE html>
<html>

<head>
  <title>Order</title>
  <!-- Bootstrap Online -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="assets/css/pelanggan.css">
</head>

<body>

  <div class="wrapper">
    <div class="title">
      Transaksi
    </div>

    <div class="form">
      <form action="simpan-transaksi.php" method="post">
        <table>
          <div class="inputfield">
            <label for="id_transaksi"></label>
            <input type="hidden" class="input" name="id_transaksi" placeholder="Masukan Id Transaksi"
              value="<?php echo $row['id_trans']; ?>">
          </div>
          <div class="inputfield">
            <label for="id_pelanggan"></label>
            <input type="hidden" class="input" name="id_pelanggan" placeholder="Masukan Id Pelanggan"
              value="<?php echo $row1['id_pe']; ?>">
          </div>
          <div class="inputfield">
            <label for="id_galon">Jenis Galon</label>
            <select type="text" class="input" id="id_galon" name="id_galon" placeholder="Masukan Jumlah Galon">
              <option value="">Pilih Jenis Galon</option>
              <?php $row_jenis = mysqli_query($connection, "SELECT * from galon");
                        while ($row2 = mysqli_fetch_array($row_jenis)) {
                            echo "<option value='$row2[id_galon]'>$row2[jenis_galon]</option>";
                            $harga = ['harga_galon'];
                        }
                        mysqli_free_result($row_jenis); // untuk penggunaan multiple prosedur
                        mysqli_next_result($connection);
                        ?>
            </select>
          </div>
          <div class="inputfield">
            <label for="jumlah_beli">Jumlah Galon</label>
            <input type="number" class="input" name="jumlah_beli" placeholder="Masukan Jumlah Galon" value="1">
          </div>
          <div class="inputfield">
            <label for="total_harga">Total Harga</label>
            <input type="number" class="input" id="total_harga" name="total_harga" placeholder="Masukan Total Harga">
          </div>
          <div class="inputfield">
            <label for="tanggal_transaksi">Tanggal Transaksi</label>
            <input type="date" class="input" name="tanggal_transaksi" placeholder="Masukan Tanggal Transaksi">
          </div>
          <div class="inputfield">
            <button type="submit" name="submit" class="btn btn-primary">Daftar Transaksi</button>
          </div>
          <a href="index.php"><button type="button" class="btn btn-danger">Batal
            </button>
        </table>
    </div>
    </form>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script>
  $(document).ready(function() {
    $('#id_galon').change(function() {
      var id = $(this).val();

      $.ajax({
        type: 'POST', //method
        url: 'data-galon.php', //action
        data: {
          id: id

        },
        success: function(data) {
          var isi = JSON.parse(data);
          $('#total_harga').val(isi.harga_galon);
        }
      });

    });
  });

  // function kalkulasi() {
  //   var nilai = $('input[name="jumlah_beli"]').val();
  //   var total = $('input[name="total_harga"]').val();
  //   var hasil = parseInt(nilai) * parseInt(total);
  //   if (!isNaN(hasil)) {
  //     $('input[name="total_harga"]').val(hasil);
  //   }
  // }
  </script>
</body>

</html>