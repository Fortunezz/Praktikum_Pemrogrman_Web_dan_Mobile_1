-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2023 at 04:56 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_air`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `tampilkan` (IN `id_par` INT(11))  BEGIN
		SELECT * FROM galon WHERE id_galon = id_par;
	END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `tes` (`JENIS` VARCHAR(32)) RETURNS VARCHAR(100) CHARSET utf8mb4 BEGIN
DECLARE hrg INT;
           SELECT harga INTO  hrg FROM transaksi 	
              WHERE jenis_galon=JENIS;
           IF (JENIS = "10 L") THEN
	      SET hrg = 5000;
              RETURN (hrg);
           elseIF (JENIS = "12 L") THEN
	      SET hrg = 6000;
              RETURN (hrg);
           ELSEIF (JENIS = "15 L") THEN
	      SET hrg = 7000;
              RETURN (hrg);
           END IF;
    END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(5) NOT NULL,
  `nama_admin` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama_admin`, `username`, `password`) VALUES
(1, 'martin kurnia', 'martin masbro', 'admin'),
(2, 'Masbro', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `galon`
--

CREATE TABLE `galon` (
  `id_galon` int(5) NOT NULL,
  `jenis_galon` enum('10 L','12 L','15 L','19 L') NOT NULL,
  `harga_galon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `galon`
--

INSERT INTO `galon` (`id_galon`, `jenis_galon`, `harga_galon`) VALUES
(1, '10 L', 5000),
(2, '12 L', 6000),
(3, '15 L', 7000),
(4, '19 L', 8000);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(5) NOT NULL,
  `nama_pelanggan` varchar(225) NOT NULL,
  `alamat` varchar(225) NOT NULL,
  `no_hp` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `alamat`, `no_hp`) VALUES
(1, 'doni ', 'jln. sangga buana no.19', '087825956965'),
(2, 'andy setiawan', 'g. obos 15', '082350785977'),
(3, 'andy dwi', 'jln. Kapuas', '082350785977'),
(4, 'yosua', 'jl. Garuda', '087825956999'),
(5, 'admin', 'jl.tamahas', '082350785977'),
(6, 'ayu', 'jl. radja', '087825956999');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(5) NOT NULL,
  `id_transaksi` int(5) NOT NULL,
  `jumlah_bayar` int(11) NOT NULL,
  `tanggal_pembayaran` date NOT NULL,
  `status_pembayaran` enum('belum dibayar','sudah dibayar') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_transaksi`, `jumlah_bayar`, `tanggal_pembayaran`, `status_pembayaran`) VALUES
(1, 1, 5000, '2023-03-17', 'belum dibayar'),
(2, 2, 12000, '2023-03-17', 'sudah dibayar'),
(3, 3, 5000, '2023-03-17', 'belum dibayar'),
(4, 4, 6000, '2023-03-17', 'belum dibayar'),
(5, 5, 5000, '2023-03-17', 'belum dibayar'),
(6, 6, 5000, '2023-03-17', 'belum dibayar');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(5) NOT NULL,
  `id_pelanggan` int(5) NOT NULL,
  `id_galon` int(5) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL,
  `tanggal_transaksi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_pelanggan`, `id_galon`, `jumlah_beli`, `total_harga`, `tanggal_transaksi`) VALUES
(1, 1, 1, 1, 5000, '2023-03-17'),
(2, 2, 2, 2, 12000, '2023-03-17'),
(3, 3, 1, 1, 5000, '2023-03-17'),
(4, 4, 2, 1, 6000, '2023-03-17'),
(5, 5, 2, 1, 6000, '2023-03-17'),
(6, 6, 1, 1, 5000, '2023-03-17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `galon`
--
ALTER TABLE `galon`
  ADD PRIMARY KEY (`id_galon`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `id_transaksi` (`id_transaksi`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_pelanggan` (`id_pelanggan`),
  ADD KEY `id_admin` (`id_galon`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi` (`id_transaksi`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`),
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_galon`) REFERENCES `galon` (`id_galon`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
