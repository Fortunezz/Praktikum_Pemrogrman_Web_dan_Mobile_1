<?php
$connection = new mysqli("localhost","root","","db_air");

// Check connection
if ($connection -> connect_error) {
  echo "Failed to connect to MySQL: " . 
  $connection -> connect_error;
  exit();
}
?>