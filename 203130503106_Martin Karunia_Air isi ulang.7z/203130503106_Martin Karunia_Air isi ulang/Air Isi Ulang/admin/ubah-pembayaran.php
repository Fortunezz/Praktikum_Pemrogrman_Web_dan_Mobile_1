<?php 
include('header.php');
require('function.php');

$id = $_GET["id_pembayaran"];
$rows = query("SELECT * FROM pembayaran WHERE id_pembayaran = $id")[0];
if (isset($_POST["submit"])) {
  if (ubah_pembayaran($_POST) > 0) {

      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'data-pembayaran.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'ubah-pembayaran.php';
  </script>";
  }
}
?>



<div class="container">
  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5">
    <div class="card-body">
      <p style="font-size: 120% ;">Ubah Data Pembayaran</p>
      <br>
      <div class=col-6>
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="id_pembayaran">Id Pembayaran</label>
              <input type="text" class="form-control" name="id_pembayaran" placeholder="Masukan Id Pembayaran"
                value="<?= $rows["id_pembayaran"] ?>">
            </div>
            <div class="form-group">
              <label for="id_transaksi">Id Transaksi</label>
              <input type="text" class="form-control" name="id_transaksi" placeholder="Masukan Id Transaksi"
                value="<?= $rows["id_transaksi"] ?>">
            </div>
            <div class="form-group">
              <label for="jumlah_bayar">Jumlah Bayar</label>
              <input type="text" class="form-control" name="jumlah_bayar" placeholder="Masukan Jumlah Bayar"
                value="<?= $rows["jumlah_bayar"] ?>">
            </div>
            <div class="form-group">
              <label for="tanggal_pembayaran">Tanggal Pembayaran</label>
              <input type="date" class="form-control" name="tanggal_pembayaran" placeholder="Masukan Tanggal Pembayaran"
                value="<?= $rows["tanggal_pembayaran"] ?>">
            </div>
            <div class="form-group">
              <label for="status_pembayaran">Status Pembayaran</label>
              <select name="status_pembayaran" id="status_pembayaran" class="form-control">
                <option value="<?= $rows["status_pembayaran"] ?>"><?= $rows["status_pembayaran"] ?></option>
                <option value="belum dibayar">belum dibayar</option>
                <option value="sudah dibayar">sudah dibayar</option>
              </select>
            </div>
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-pelanggan.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>
<?php 
include('footer.php');
?>