<?php 
include('header.php');
require('function.php');

if (isset($_POST["submit"])) {
  if (tambah_admin($_POST) > 0) {

      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'data-admin.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'tambah-admin.php';
  </script>";
  }
}
?>

<?php
include("../connection.php");
$data = mysqli_query($connection, "SELECT max((id_admin) + 1) as id_ad FROM admin");
$row = mysqli_fetch_array($data);
?>

<div class="container">
  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5">
    <div class="card-body">
      <p style="font-size: 120% ;">Tambah Data admin</p>
      <br>
      <div class=col-6>
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="id_admin">Id Admin</label>
              <input type="text" class="form-control" name="id_admin" placeholder="Masukan Id Admin"
                value="<?php echo $row['id_ad']; ?>">
            </div>
            <div class="form-group">
              <label for="nama_admin">Nama Admin</label>
              <input type="text" class="form-control" name="nama_admin" placeholder="Masukan Nama Admin" required>
            </div>
            <div class="form-group">
              <label for="username">Username</label>
              <input type="text" class="form-control" name="username" placeholder="Masukan Username Admin" required>
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" name="password" placeholder=" Masukan Password Admin"
                required>
            </div>
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-admin.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>
<?php 
include('footer.php');
?>