<?php 
include('header.php');
require('function.php');

$id = $_GET["id_galon"];
$rows = query("SELECT * FROM galon WHERE id_galon = $id")[0];
if (isset($_POST["submit"])) {
  if (ubah_galon($_POST) > 0) {

      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'data-galon.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'ubah-galon.php';
  </script>";
  }
}
?>

<div class="container">
  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5">
    <div class="card-body">
      <p style="font-size: 120% ;">Ubah Data Galon</p>
      <br>
      <div class=col-6>
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="id_galon">Id galon</label>
              <input type="text" class="form-control" name="id_galon" placeholder="Masukan Id galon"
                value="<?= $rows["id_galon"] ?>">
            </div>
            <div class="form-group">
              <label for="jenis_galon">Jenis Galon</label>
              <input type="text" class="form-control" name="jenis_galon" placeholder="Masukan Jenis Galon"
                value="<?= $rows["jenis_galon"] ?>">
            </div>
            <div class="form-group">
              <label for="harga_galon">Harga Galon</label>
              <input type="text" class="form-control" name="harga_galon" placeholder="Masukan harga galon"
                value="<?= $rows["harga_galon"] ?>">
            </div>
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-galon.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>
<?php 
include('footer.php');
?>