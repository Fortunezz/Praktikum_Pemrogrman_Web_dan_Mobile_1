<?php 
include('header.php');
require('function.php');

$id = $_GET["id_transaksi"];
$rows = query("SELECT * FROM transaksi WHERE id_transaksi = $id")[0];
if (isset($_POST["submit"])) {
  if (ubah_transaksi($_POST) > 0) {
      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'data-transaksi.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'ubah-transaksi.php';
  </script>";
  }
}
?>

<div class="container">
  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5">
    <div class="card-body">
      <p style="font-size: 120% ;">Ubah Data Transsksi</p>
      <br>
      <div class="col-6">
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="id_transaksi">Id Transaksi</label>
              <input type="text" class="form-control" name="id_transaksi" placeholder="Masukan Id Transaksi"
                value="<?= $rows["id_transaksi"] ?>">
            </div>
            <div class="form-group">
              <label for="id_pelanggan">Id Pelanggan</label>
              <input type="text" class="form-control" name="id_pelanggan" placeholder="Masukan Id Pelanggan"
                value="<?= $rows["id_pelanggan"] ?>">
            </div>
            <div class="form-group">
              <label for="id_galon">Id galon</label>
              <input type="text" class="form-control" name="id_galon" placeholder="Masukan id galon "
                value="<?= $rows["id_galon"] ?>">
            </div>

            <div class="form-group">
              <label for="jenis_galon">Jenis Galon</label>
              <select name="jenis_galon" id="jenis_galon" class="form-control">
                <option value="<?= $rows["jenis_galon"] ?>"><?= $rows["jenis_galon"] ?></option>
                <option value="10 L">10 L</option>
                <option value="12 L">12 L</option>
                <option value="15 L">15 L</option>
                <option value="19 L">19 L</option>
              </select>
            </div>
            <div class="form-group">
              <label for="jumlah_galon">Jumlah galon</label>
              <input type="text" class="form-control" name="jumlah_galon" placeholder=" Masukan Jumlah Galon"
                value="<?= $rows["jumlah_galon"] ?>">
            </div>

            <div class="form-group">
              <label for="total_harga">Total harga</label>
              <input type="text" class="form-control" name="total_harga" placeholder=" Masukan Total Harga"
                value="<?= $rows["total_harga"] ?>">
            </div>

            <div class="form-group">
              <label for="tanggal_transaksi">Tanggal Transaksi</label>
              <input type="date" id="tanggal_transaksi" class="form-control" name="tanggal_transaksi"
                value="<?= $rows["tanggal_transaksi"] ?>">
            </div>
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-transaksi.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>

<?php 
include("footer.php");
?>