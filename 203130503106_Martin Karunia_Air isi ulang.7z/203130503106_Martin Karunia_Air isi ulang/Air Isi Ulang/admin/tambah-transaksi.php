<?php 
include('header.php');
require('function.php');

if (isset($_POST["submit"])) {
  if (tambah_transaksi($_POST) > 0) {
      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'data-transaksi.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'tambah-transaksi.php';
  </script>";
  }
}
?>


<?php
include("../connection.php");
$data = mysqli_query($connection, "SELECT max((id_transaksi) + 1) as id_trans FROM transaksi");
$data1 = mysqli_query($connection, "SELECT max(id_pelanggan) as id_pe FROM pelanggan");
$row = mysqli_fetch_array($data);
$row1 = mysqli_fetch_array($data1);
?>

<div class="container">
  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5">
    <div class="card-body">
      <p style="font-size: 120% ;">Tambah Data Transsksi</p>
      <br>
      <div class="col-6">
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="id_transaksi">Id Transaksi</label>
              <input type="text" class="form-control" name="id_transaksi" placeholder="Masukan Id Transaksi"
                value="<?php echo $row['id_trans']; ?>">
            </div>
            <div class="form-group">
              <label for="id_pelanggan">Id Pelanggan</label>
              <input type="text" class="form-control" name="id_pelanggan" placeholder="Masukan Id Pelanggan"
                value="<?php echo $row1['id_pe']; ?>">
            </div>
            <div class="form-group">
              <label for="id_galon">Id galon</label>
              <input type="text" class="form-control" name="id_galon" placeholder="Masukan id galon " required>
            </div>
            <div class="form-group">
              <label for="jumlah_galon">Jumlah galon</label>
              <input type="text" class="form-control" name="jumlah_galon" placeholder=" Masukan Harga" required>
            </div>
            <div class="form-group">
              <label for="total_harga">Total harga</label>
              <input type="text" class="form-control" name="total_harga" placeholder=" Masukan Total Harga" required>
            </div>

            <div class="form-group">
              <label for="tanggal_transaksi">Tanggal Transaksi</label>
              <input type="date" id="tanggal_transaksi" class="form-control" name="tanggal_transaksi">
            </div>
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-transaksi.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>

<?php 
include("footer.php");
?>