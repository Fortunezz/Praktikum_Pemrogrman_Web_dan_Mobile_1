<?php 
include('header.php');

include("../connection.php");
$data1 = mysqli_query($connection, "SELECT max(id_admin) as id_ad FROM admin");
$data2 = mysqli_query($connection, "SELECT max(id_pelanggan) as id_pe FROM pelanggan");
$data3 = mysqli_query($connection, "SELECT max(id_transaksi) as id_trans FROM transaksi");
$data4 = mysqli_query($connection, "SELECT sum(jumlah_bayar) as jumlah FROM pembayaran");
$data5 = mysqli_query($connection, "SELECT max(id_galon) as id_ga FROM galon");
$admin = mysqli_fetch_array($data1);
$pelanggan = mysqli_fetch_array($data2);
$transaksi = mysqli_fetch_array($data3);
$pembayaran = mysqli_fetch_array($data4);
$galon = mysqli_fetch_array($data5);
?>
<style>
.f-28 {
  font-size: 28px;
}

.text-muted {
  color: #78909c !important;
}

.bg-c-purple {
  background: #536dfe;
}

.bg-c-green {
  background: #11c15b;
}

.bg-c-red {
  background: #ff5252;
}

.bg-c-blue {
  background: #448aff;
}

.bg-c-orange {
  background: #ff8000;
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<div class="container-lg" style="margin-top: 4.5rem">
  <!-- Page-header end -->
  <div class="pcoded-inner-content">
    <!-- Main-body start -->
    <div class="main-body">
      <div class="page-wrapper">
        <!-- Page-body start -->
        <div class="page-body">
          <div class="row mt-3">

            <div class="col-xl-4 col-md-6">
              <div class="card">
                <div class="card-block p-3">
                  <div class="row align-items-center">
                    <div class="col-8">
                      <h4 class="text-c-green" value="<?php echo $pelanggan['id_pe']; ?>">
                        <?php echo $pelanggan['id_pe']. " Orang"; ?>
                      </h4>
                      <h6 class="text-muted m-b-0">Pelanggan</h6>
                    </div>
                    <div class="col-4 text-right">
                      <i class="fa fa-user f-28"></i>
                    </div>
                  </div>
                </div>
                <div class="card-footer bg-c-green">
                  <div class="row align-items-center">
                    <div class="col-9">
                      <a href="data-pelanggan.php">
                        <p class="text-white m-b-0">% change
                        </p>
                      </a>
                    </div>
                    <div class="col-3 text-right">
                      <i class="fa fa-line-chart text-white f-16"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-4 col-md-6">
              <div class="card">
                <div class="card-block p-3">
                  <div class="row align-items-center">
                    <div class="col-8">
                      <h4 class="text-c-green" value="<?php echo $galon['id_ga']; ?>">
                        <?php echo $galon['id_ga']. " Jenis"; ?>
                      </h4>
                      <h6 class="text-muted m-b-0">galon</h6>
                    </div>
                    <div class="col-4 text-right">
                      <i class="fa fa-database f-28"></i>
                    </div>
                  </div>
                </div>
                <div class="card-footer bg-c-orange">
                  <div class="row align-items-center">
                    <div class="col-9">
                      <a href="data-galon.php">
                        <p class="text-white m-b-0">% change
                        </p>
                      </a>
                    </div>
                    <div class="col-3 text-right">
                      <i class="fa fa-line-chart text-white f-16"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-4 col-md-6">
              <div class="card">
                <div class="card-block p-3">
                  <div class="row align-items-center">
                    <div class="col-8">
                      <h4 class="text-c-red" value="<?php echo $transaksi['id_trans']; ?>">
                        <?php echo $transaksi['id_trans']. " Kali"; ?></h4>
                      <h6 class="text-muted m-b-0">Transaksi</h6>
                    </div>
                    <div class="col-4 text-right">
                      <i class="fa fa-list-ul f-28"></i>
                    </div>
                  </div>
                </div>
                <div class="card-footer bg-c-red">
                  <div class="row align-items-center">
                    <div class="col-9">
                      <a href="data-transaksi.php">
                        <p class="text-white m-b-0">% change
                        </p>
                      </a>
                    </div>
                    <div class="col-3 text-right">
                      <i class="fa fa-line-chart text-white f-16"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-md-6 mt-4">
              <div class="card">
                <div class="card-block p-3">
                  <div class="row align-items-center">
                    <div class="col-8">
                      <h4 class="text-c-blue" value="<?php echo $admin['id_ad']; ?>">
                        <?php echo $admin['id_ad']. " Orang"; ?></h4>
                      <h6 class="text-muted m-b-0">Admin</h6>
                    </div>
                    <div class="col-4 text-right">
                      <i class="fa fa-user-shield f-28"></i>
                    </div>
                  </div>
                </div>
                <div class="card-footer bg-c-blue">
                  <div class="row align-items-center">
                    <div class="col-9">
                      <a href="data-admin.php">
                        <p class="text-white m-b-0">% change
                        </p>
                      </a>
                    </div>
                    <div class="col-3 text-right">
                      <i class="fa fa-line-chart text-white f-16"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- task, page, download counter  start -->
            <div class="col-xl-4 col-md-6 mt-4">
              <div class="card">
                <div class="card-block p-3">
                  <div class="row align-items-center">
                    <div class="col-8">
                      <h4 class="text-purplevalue=" <?php echo $pembayaran['jumlah']; ?>">
                        <?php echo "Rp. ".$pembayaran['jumlah']; ?></h4>
                      <h6 class="text-muted m-b-0">Pembayaran</h6>
                    </div>
                    <div class="col-4 text-right">
                      <i class="fa fa-bar-chart f-28"></i>
                    </div>
                  </div>
                </div>
                <div class="card-footer bg-c-purple">
                  <div class="row align-items-center">
                    <div class="col-9">
                      <a href="data-pembayaran.php">
                        <p class="text-white m-b-0">% change
                        </p>
                      </a>
                    </div>
                    <div class="col-3 text-right">
                      <i class="fa fa-line-chart text-white f-16"></i>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php 
include('footer.php');
?>