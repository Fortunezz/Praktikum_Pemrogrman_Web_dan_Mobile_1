<?php 
require('function.php');

$id = $_GET["id_admin"];
if (hapus_admin($id) > 0) {
	echo "
				<script>
					alert('Data berhasil dihapus!');
					document.location.href = 'data-admin.php';
				</script>
		";
} else {
	echo "
		<script>
					alert('Data gagal dihapus!');
					document.location.href = 'data-admin.php';
				</script>
		";
}
?>