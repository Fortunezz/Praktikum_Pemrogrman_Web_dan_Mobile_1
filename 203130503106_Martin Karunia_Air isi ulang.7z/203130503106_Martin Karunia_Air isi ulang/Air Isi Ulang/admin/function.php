<?php 
require("../connection.php");

function query($query)
{
    global $connection;
    $result = mysqli_query($connection, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function tambah_pelanggan($data)
{
  global $connection;
  $id_pelanggan = htmlspecialchars($data["id_pelanggan"]);
  $nama_pelanggan = htmlspecialchars($data["nama_pelanggan"]);
  $alamat = htmlspecialchars($data["alamat"]);
  $no_hp = htmlspecialchars($data["no_hp"]);

  $query = "INSERT INTO pelanggan VALUES ('$id_pelanggan','$nama_pelanggan','$alamat','$no_hp')";
  mysqli_query($connection, $query);
  return mysqli_affected_rows($connection);
}

function ubah_pelanggan($data)
{
  global $connection;
  $id_pelanggan = htmlspecialchars($data["id_pelanggan"]);
  $nama_pelanggan = htmlspecialchars($data["nama_pelanggan"]);
  $alamat = htmlspecialchars($data["alamat"]);
  $no_hp = htmlspecialchars($data["no_hp"]);

    $query = "UPDATE pelanggan SET 
             nama_pelanggan ='$nama_pelanggan',
             alamat ='$alamat',
             no_hp ='$no_hp'
             WHERE id_pelanggan = $id_pelanggan
             ";
    mysqli_query($connection, $query);
    return mysqli_affected_rows($connection);
}

function hapus_pelanggan($id)
{
    global $connection;
    mysqli_query($connection, "DELETE FROM pelanggan WHERE id_pelanggan = $id");
    return mysqli_affected_rows($connection);
}

function hapus_admin($id)
{
  global $connection;
  mysqli_query($connection, "DELETE FROM admin WHERE id_admin = $id");
  return mysqli_affected_rows($connection);
}


function ubah_admin($data)
{
  global $connection;
  $id_admin = htmlspecialchars($data["id_admin"]);
  $nama_admin = htmlspecialchars($data["nama_admin"]);
  $username = htmlspecialchars($data["username"]);
  $password = htmlspecialchars($data["password"]);
  
  $query = "UPDATE admin SET 
             nama_admin ='$nama_admin',
             username ='$username',
             password ='$password'
             WHERE id_admin = $id_admin
             ";
    mysqli_query($connection, $query);
    return mysqli_affected_rows($connection);
  }
  
  function tambah_admin($data)
  {
    global $connection;
    $id_admin = htmlspecialchars($data["id_admin"]);
    $nama_admin = htmlspecialchars($data["nama_admin"]);
    $username = htmlspecialchars($data["username"]);
    $password = htmlspecialchars($data["password"]);
  
    $query = "INSERT INTO admin VALUES ('$id_admin','$nama_admin','$username','$password')";
    mysqli_query($connection, $query);
    return mysqli_affected_rows($connection);
  }
  
  
  function tambah_transaksi($data)
  {
  global $connection;
  $id_transaksi = htmlspecialchars($data["id_transaksi"]);
  $id_pelanggan = htmlspecialchars($data["id_pelanggan"]);
  $id_galon = htmlspecialchars($data["id_galon"]);
  $jumlah_galon = htmlspecialchars($data["jumlah_beli"]);
  $total_harga = htmlspecialchars($data["total_harga"]);
  $tanggal_transaksi = htmlspecialchars($data["tanggal_transaksi"]);
  
  
  $query = "INSERT INTO transaksi VALUES ('$id_transaksi','$id_pelanggan','$id_galon','$jumlah_galon','$total_harga','$tanggal_transaksi')";
  
  mysqli_query($connection, $query);
  return mysqli_affected_rows($connection);
}


function ubah_transaksi($data)
{
  global $connection;
  $id_transaksi = htmlspecialchars($data["id_transaksi"]);
  $id_pelanggan = htmlspecialchars($data["id_pelanggan"]);
  $id_galon = htmlspecialchars($data["id_galon"]);
  $jumlah_galon = htmlspecialchars($data["jumlah_beli"]);
  $total_harga = htmlspecialchars($data["total_harga"]);
  $tanggal_transaksi = htmlspecialchars($data["tanggal_transaksi"]);

    $query = "UPDATE transaksi SET 
             id_transaksi = '$id_transaksi',
             id_pelanggan = '$id_pelanggan',
             id_galon = '$id_galon',
             jumlah_beli ='$jumlah_galon',
             total_harga = '$total_harga',
             tanggal_transaksi = '$tanggal_transaksi'
             WHERE id_transaksi = $id_transaksi
             ";
    mysqli_query($connection, $query);
    return mysqli_affected_rows($connection);
}


function hapus_transaksi($id)
{
  global $connection;
  mysqli_query($connection, "DELETE FROM transaksi WHERE id_transaksi = $id");
  return mysqli_affected_rows($connection);
}


function tambah_pembayaran($data)
{
  global $connection;
  $id_pembayaran = htmlspecialchars($data["id_pembayaran"]);
  $id_transaksi = htmlspecialchars($data["id_transaksi"]);
  $jumlah_bayar = htmlspecialchars($data["jumlah_bayar"]);
  $tanggal_pembayaran = htmlspecialchars($data["tanggal_pembayaran"]);
  $status_pembayaran = htmlspecialchars($data["status_pembayaran"]);
  
  $query = "INSERT INTO pembayaran VALUES ('$id_pembayaran','$id_transaksi','$jumlah_bayar','$tanggal_pembayaran','$status_pembayaran')";
  mysqli_query($connection, $query);
  return mysqli_affected_rows($connection);
}


function hapus_pembayaran($id)
{
  global $connection;
  mysqli_query($connection, "DELETE FROM pembayaran WHERE id_pembayaran = $id");
  return mysqli_affected_rows($connection);
}


function ubah_pembayaran($data)
{
  global $connection;
  $id_pembayaran = htmlspecialchars($data["id_pembayaran"]);
  $id_transaksi = htmlspecialchars($data["id_transaksi"]);
  $jumlah_bayar = htmlspecialchars($data["jumlah_bayar"]);
  $tanggal_pembayaran = htmlspecialchars($data["tanggal_pembayaran"]);
  $status_pembayaran = htmlspecialchars($data["status_pembayaran"]);

    $query = "UPDATE pembayaran SET 
             id_pembayaran = '$id_pembayaran',
             id_transaksi = '$id_transaksi',
             jumlah_bayar ='$jumlah_bayar',
             tanggal_pembayaran ='$tanggal_pembayaran',
             status_pembayaran ='$status_pembayaran'
             WHERE id_pembayaran = $id_pembayaran
             ";
    mysqli_query($connection, $query);
    return mysqli_affected_rows($connection);
}


function tambah_galon($data)
{
  global $connection;
  $id_galon = htmlspecialchars($data["id_galon"]);
  $jenis_galon = htmlspecialchars($data["jenis_galon"]);
  $harga_galon = htmlspecialchars($data["harga_galon"]);
  
  $query = "INSERT INTO galon VALUES ('$id_galon','$jenis_galon','$harga_galon')";
  mysqli_query($connection, $query);
  return mysqli_affected_rows($connection);
}

function hapus_galon($id)
{
  global $connection;
  mysqli_query($connection, "DELETE FROM galon WHERE id_galon = $id");
  return mysqli_affected_rows($connection);
}


function ubah_galon($data)
{
  global $connection;
  $id_galon = htmlspecialchars($data["id_galon"]);
  $jenis_galon = htmlspecialchars($data["jenis_galon"]);
  $harga_galon = htmlspecialchars($data["harga_galon"]);
  
  $query = "UPDATE galon SET 
             id_galon ='$id_galon',
             jenis_galon ='$jenis_galon',
             harga_galon ='$harga_galon'
             WHERE id_galon = $id_galon
             ";
    mysqli_query($connection, $query);
    return mysqli_affected_rows($connection);
  }
?>