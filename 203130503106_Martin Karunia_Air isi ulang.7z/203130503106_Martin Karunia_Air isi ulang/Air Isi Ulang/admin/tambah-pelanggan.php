<?php 
include('header.php');
require('function.php');

if (isset($_POST["submit"])) {
  if (tambah_pelanggan($_POST) > 0) {

      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'data-pelanggan.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'tambah-pelanggan.php';
  </script>";
  }
}
?>

<?php
include("../connection.php");
$data = mysqli_query($connection, "SELECT max((id_pelanggan) + 1) as id_pe FROM pelanggan");
$row = mysqli_fetch_array($data);
?>

<div class="container">
  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5">
    <div class="card-body">
      <p style="font-size: 120% ;">Tambah Data Pelanggan</p>
      <br>
      <div class=col-6>
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="id_pelanggan">Id Pelanggan</label>
              <input type="text" class="form-control" name="id_pelanggan" placeholder="Masukan Id Pelanggan"
                value="<?php echo $row['id_pe']; ?>">
            </div>
            <div class="form-group">
              <label for="nama_pelanggan">Nama Pelanggan</label>
              <input type="text" class="form-control" name="nama_pelanggan" placeholder="Masukan Nama Pelanggan"
                required>
            </div>
            <div class="form-group">
              <label for="alamat">Alamat</label>
              <input type="text" class="form-control" name="alamat" placeholder="Masukan Alamat Pelanggan" required>
            </div>
            <div class="form-group">
              <label for="no_hp">No. Hp</label>
              <input type="telp" class="form-control" name="no_hp" placeholder=" Masukan No Hp Pelanggan" required>
            </div>
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-pelanggan.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>
<?php 
include('footer.php');
?>