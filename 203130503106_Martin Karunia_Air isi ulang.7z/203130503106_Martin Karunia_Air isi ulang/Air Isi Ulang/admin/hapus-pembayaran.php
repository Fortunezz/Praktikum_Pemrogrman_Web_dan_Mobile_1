<?php 
require('function.php');

$id = $_GET["id_pembayaran"];
if (hapus_pembayaran($id) > 0) {
	echo "
				<script>
					alert('Data berhasil dihapus!');
					document.location.href = 'data-pembayaran.php';
				</script>
		";
} else {
	echo "
		<script>
					alert('Data gagal dihapus!');
					document.location.href = 'data-pembayaran.php';
				</script>
		";
}
?>