<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <title>Admin</title>
  <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../assets/vendors/font-awesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="../assets/css/admin.css" />

</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_sidebar.html -->
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav">
        <li class="pt-2 pb-1 text-center border-bottom">
          <span class="nav-item" style="font-size:1rem;"></span>
        </li>
        <li class="nav-item nav-profile border-bottom">
          <a href="#" class="nav-link flex-column">
            <div class="nav-profile-image">
              <img src="https://drive.google.com/uc?id=1iYl1FHzlcvrzTriOAFzgBwXObb4y6UWH" alt="profile"
                style="border: 1px solid black;" />
            </div>
            <div class="nav-profile-text d-flex ml-0 mb-3 flex-column">
              <span class="font-weight-semibold mb-1 mt-2 text-center">Martin Kurnia</span>
              <span class="text-secondary icon-sm text-center">Admin</span>
            </div>
          </a>
        </li>

        <li class="nav-item border-bottom">
          <a class="nav-link" href="halaman-utama-admin.php">
            <i class="mdi mdi-compass-outline menu-icon"></i>
            <span class="menu-title">Dashboard</span>
          </a>
        </li>
        <li class="nav-item border-bottom">
          <a class="nav-link" href="data-pelanggan.php">
            <i class="mdi mdi-contacts menu-icon"></i>
            <span class="menu-title">Pelanggan</span>
          </a>
        </li>
        <li class="nav-item border-bottom">
          <a class="nav-link" href="data-galon.php">
            <i class="mdi mdi-database menu-icon"></i>
            <span class="menu-title">Galon</span>
          </a>
        </li>
        <li class="nav-item border-bottom">
          <a class="nav-link" href="data-transaksi.php">
            <i class="mdi mdi-format-list-bulleted menu-icon"></i>
            <span class="menu-title">Transaksi</span>
          </a>
        </li>
        <li class="nav-item border-bottom">
          <a class="nav-link" href="data-pembayaran.php">
            <i class="mdi mdi-chart-bar menu-icon"></i>
            <span class="menu-title">Pembayaran</span>
          </a>
        </li>
        <li class="nav-item border-bottom">
          <a class="nav-link" href="data-admin.php">
            <i class="mdi mdi-account-key menu-icon"></i>
            <span class="menu-title">Admin</span>
          </a>
        </li>
        <li class="nav-item pt-3 border-bottom">
          <a class="nav-link" href="logout.php">
            <i class="mdi mdi-logout menu-icon"></i>
            <span class="menu-title">Keluar</span>
          </a>
        </li>
      </ul>
    </nav>


    <div class="container-fluid page-body-wrapper">
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-chevron-double-left"></span>
          </button>
          <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
            <a class="navbar-brand brand-logo-mini" href="halaman-utama-admin.php"><img
                src="../assets/images/logo-mini.svg" alt="logo" /></a>
          </div>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-logout d-none d-lg-block">
              <a class="nav-link" href="halaman-utama-admin.php">
                <i class="mdi mdi-home-circle"></i>
              </a>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
            data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>