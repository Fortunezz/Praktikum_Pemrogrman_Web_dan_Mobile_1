<?php 
include('header.php');
require('function.php');

if (isset($_POST["submit"])) {
  if (tambah_pembayaran($_POST) > 0) {

      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'data-pembayaran.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'tambah-pembayaran.php';
  </script>";
  }
}
?>

<?php
include("../connection.php");
$data = mysqli_query($connection, "SELECT max((id_pembayaran) + 1) as id_pem FROM pembayaran");
$data1 = mysqli_query($connection, "SELECT max(id_transaksi) as id_trans FROM transaksi");
$row = mysqli_fetch_array($data);
$row1 = mysqli_fetch_array($data1);
?>

<div class="container">
  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5">
    <div class="card-body">
      <p style="font-size: 120% ;">Tambah Data Pembayaran</p>
      <br>
      <div class=col-6>
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="id_pembayaran">Id Pembayaran</label>
              <input type="text" class="form-control" name="id_pembayaran" placeholder="Masukan Id Pembayaran"
                value="<?php echo $row['id_pem']; ?>">
            </div>
            <div class="form-group">
              <label for="id_transaksi">Id Transaksi</label>
              <input type="text" class="form-control" name="id_transaksi" placeholder="Masukan Id Transaksi"
                value="<?php echo $row1['id_trans']; ?>">
            </div>
            <div class="form-group">
              <label for="jumlah_bayar">Jumlah Bayar</label>
              <input type="text" class="form-control" name="jumlah_bayar" placeholder="Masukan Jumlah Bayar" required>
            </div>
            <div class="form-group">
              <label for="tanggal_pembayaran">Tanggal Pembayaran</label>
              <input type="date" class="form-control" name="tanggal_pembayaran" placeholder="Masukan Tanggal Pembayaran"
                required>
            </div>
            <div class="form-group">
              <label for="status_pembayaran">Status Pembayaran</label>
              <select name="status_pembayaran" id="status_pembayaran" class="form-control">
                <option value="belum dibayar">belum dibayar</option>
                <option value="sudah dibayar">sudah dibayar</option>
              </select>
            </div>
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-pelanggan.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>
<?php 
include('footer.php');
?>