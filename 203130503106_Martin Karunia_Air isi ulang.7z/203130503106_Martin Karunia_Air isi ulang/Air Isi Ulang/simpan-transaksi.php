<?php include("connection.php");
require('function.php');
if(isset($_POST['submit'])){
  $id_transaksi = $_POST["id_transaksi"];
  $id_pelanggan = $_POST["id_pelanggan"];
  $id_galon = $_POST["id_galon"];
  $jumlah_galon = $_POST["jumlah_beli"];
  $total_harga = $_POST["total_harga"];
  $tanggal_transaksi = $_POST["tanggal_transaksi"];


  $data = mysqli_num_rows(mysqli_query($connection,"SELECT * FROM transaksi WHERE id_transaksi = '$id_transaksi'"));
  if($data >0 ){
   echo "<script>alert('Gagal');window.location='daftar-transaksi.php'</script>";

 }else{
  mysqli_query($connection,"INSERT INTO transaksi VALUES ('$id_transaksi' ,'$id_pelanggan', '$id_galon', '$jumlah_galon','$total_harga','$tanggal_transaksi')");

  echo '<script>alert("Berhasil");window.location="berhasil.php?idm='.$id_pelanggan.'"</script>';
}
}
mysqli_close($connection);
?>