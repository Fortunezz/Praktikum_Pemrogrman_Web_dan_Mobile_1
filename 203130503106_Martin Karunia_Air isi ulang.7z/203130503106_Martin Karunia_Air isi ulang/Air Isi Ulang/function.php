<?php 

require("connection.php");

function query($query)
{
    global $connection;
    $result = mysqli_query($connection, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function tambah_pelanggan($data)
{
global $connection;
$id_pelanggan = htmlspecialchars($data["id_pelanggan"]);
$nama_pelanggan = htmlspecialchars($data["nama_pelanggan"]);
$alamat = htmlspecialchars($data["alamat"]);
$no_hp = htmlspecialchars($data["no_hp"]);

$query = "INSERT INTO pelanggan VALUES ('$id_pelanggan','$nama_pelanggan','$alamat','$no_hp')";
mysqli_query($connection, $query);
return mysqli_affected_rows($connection);
}


function tambah_transaksi($data)
{
global $connection;
$id_transaksi = htmlspecialchars($data["id_transaksi"]);
$id_pelanggan = htmlspecialchars($data["id_pelanggan"]);
$id_galon = htmlspecialchars($data["id_galon"]);
$jumlah_galon = htmlspecialchars($data["jumlah_beli"]);
$total_harga = htmlspecialchars($data["total_harga"]);
$tanggal_transaksi = htmlspecialchars($data["tanggal_transaksi"]);


$query = "INSERT INTO transaksi VALUES ('$id_transaksi','$id_pelanggan','$id_galon','$jumlah_galon','$total_harga','$tanggal_transaksi')";

mysqli_query($connection, $query);
return mysqli_affected_rows($connection);
}

function tambah_pembayaran($data)
{
global $connection;
$id_pembayaran = htmlspecialchars($data["id_pembayaran"]);
$id_transaksi = htmlspecialchars($data["id_transaksi"]);
$jumlah_bayar = htmlspecialchars($data["jumlah_bayar"]);
$tanggal_pembayaran = htmlspecialchars($data["tanggal_pembayaran"]);
$status_pembayaran = htmlspecialchars($data["status_pembayaran"]);

$query = "INSERT INTO pembayaran VALUES ('$id_pembayaran','$id_transaksi','$jumlah_bayar','$tanggal_pembayaran','$status_pembayaran')";
mysqli_query($connection, $query);
return mysqli_affected_rows($connection);
}


?>