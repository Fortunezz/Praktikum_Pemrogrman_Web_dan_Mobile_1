<!DOCTYPE html>
<html>

<head>
  <title>Berhasil</title>
  <!-- Bootsrap Online -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

  <!-- CSS -->
  <link rel="stylesheet" href="assets/css/fontawesome.css">
  <link rel="stylesheet" type="text/css" href="assets/css/pelanggan.css">

</head>

<body>

  <div class="wrapper" style="border: 2px solid black;">
    <div class="title" style="color:black ;">
      Informasi Transaksi
    </div>

    <?php
    include("connection.php");
    $idm = $_GET['idm']; 
    $data = mysqli_query ($connection,"SELECT transaksi.id_transaksi, pelanggan.id_pelanggan, pelanggan.nama_pelanggan, galon.jenis_galon, galon.harga_galon,transaksi.jumlah_beli, 
    SUM(transaksi.total_harga * transaksi.jumlah_beli) AS total 
    FROM transaksi JOIN pelanggan USING (id_pelanggan) 
    JOIN galon USING (id_galon) WHERE id_pelanggan = '$idm'");
    while ($row= mysqli_fetch_array($data)){
      ?>
    <table style="width: 70%;">
      <tr>
        <td>No. Transaksi</td>
        <td> : </td>
        <td><?php echo $row['id_transaksi'];?></td>
      </tr>
      <tr>
        <td>Nama Pelanggan</td>
        <td> : </td>
        <td><?php echo $row['nama_pelanggan'];?></td>
      </tr>
      <tr>
        <td>Jenis Galon</td>
        <td> : </td>
        <td><?php echo $row['jenis_galon'];?></td>
      </tr>
      <tr>
        <td>Harga Galon Satuan</td>
        <td> : </td>
        <td><?php echo $row['harga_galon'];?></td>
      </tr>
      <tr>
        <td>Jumlah Beli</td>
        <td> : </td>
        <td><?php echo $row['jumlah_beli'];?></td>
      </tr>
      <tr>
        <td>Total Harga</td>
        <td> : </td>
        <td><?php echo $row['total'];?></td>
      </tr>
  </div>
  <div class="form-group">
    <input type="hidden" class="form-control" name="id_transaksi" value="<?php echo $row['id_transaksi']; ?>">
  </div>
  </table>
  <?php 
  }
  ?>
  <br>
  <p style="color: green;">Orderan Diterima, Silahkan Melakukan Pembayaran Langsung, sesuai dengan tertera di atas </p>

  <a href="index.php"><button type="button" class="btn btn-info">Kembali
    </button>
    </div>
</body>

</html>