<?php 
require('function.php');

if (isset($_POST["submit"])) {
  if (tambah_pelanggan($_POST) > 0) {

      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'daftar-transaksi.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'daftar-pelanggan.php';
  </script>";
  }
}
?>

<?php
include("connection.php");
$data = mysqli_query($connection, "SELECT max((id_pelanggan) + 1) as id_pe FROM pelanggan");
$row = mysqli_fetch_array($data);
?>

<!DOCTYPE html>
<html>

<head>
  <title>Order</title>
  <!-- Bootstrap Online -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="assets/css/pelanggan.css">
</head>

<body>

  <div class="wrapper">
    <div class="title">
      Pelanggan
    </div>

    <div class="form">
      <form method="POST">
        <table>
          <div class="inputfield">
            <label for="id_pelanggan"></label>
            <input type="hidden" class="input" name="id_pelanggan" placeholder="Masukan Id Pelanggan"
              value="<?php echo $row['id_pe']; ?>">
          </div>
          <div class="inputfield">
            <label for="nama_pelanggan">Nama Pelanggan</label>
            <input type="text" class="input" name="nama_pelanggan" placeholder="Masukan Nama Pelanggan" required>
          </div>
          <div class="inputfield">
            <label for="alamat">Alamat</label>
            <textarea class="textarea" class="input" name="alamat" placeholder="Masukan Alamat Pelanggan"
              required></textarea>
          </div>
          <div class="inputfield">
            <label for="no_hp">No. Hp</label>
            <input type="telp" pattern="^\d{12}$" class="input" name="no_hp" placeholder="Masukan No Hp Pelanggan"
              required>
          </div>
          <div class="inputfield">
            <button type="submit" name="submit" class="btn btn-primary">Daftar Pelanggan</button>
          </div>
          <a href="index.php"><button type="button" class="btn btn-danger">Batal
            </button>
        </table>
    </div>
    </form>
  </div>
</body>

</html>