<?php

include "connection.php";

$id = $_POST['id'];

$query = "CALL tampilkan('" . $id . "')";

$ambildata = mysqli_query($connection, $query);
if(!$ambildata){
    die("Gagal ambil data galon ". $id .mysqli_error($connection));

}

while($row = mysqli_fetch_assoc($ambildata)){
    $data = $row;
    echo json_encode($data);
}